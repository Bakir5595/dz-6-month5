import React from 'react';
import UserForm from "./components /UserForm.jsx";

const App = () => {
    return (
        <div>
            <UserForm/>
        </div>
    );
};

export default App;